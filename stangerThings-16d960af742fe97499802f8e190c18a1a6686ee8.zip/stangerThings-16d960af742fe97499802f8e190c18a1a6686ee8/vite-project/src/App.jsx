
import './App.css'
import Hero from './components/Hero'

function App() {

  return (
    <>
     <Hero />
    </>
  )
}

export default App
